import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import AppLayout from './layout/AppLayout'
import RestaurantAddPage from './pages/RestaurantAddPage'
import RestaurantDetailPage from './pages/RestaurantDetailPage'
import RestaurantListPage from './pages/RestaurantListPage'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Navigate to="/restaurants" replace />} />
          <Route path="/restaurants" element={<RestaurantListPage />} />
          <Route path="/restaurants/new" element={<RestaurantAddPage />} />
          <Route path="/restaurants/:id" element={<RestaurantDetailPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
