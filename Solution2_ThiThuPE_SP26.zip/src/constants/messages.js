export const MESSAGE = {
  MS01: (field) => `${field} is required.`,
  MS02: (field, min, max) => `${field} must be greater than or equal ${min} and less than or equal ${max}`,
  MS03: 'The input value is invalid format date.',
  MS04: 'Created new restaurant successfully',
  MS05: 'Internal system error, please contact with administrator',
  MS08: 'Deleted successfully',
}
