import { Container } from 'react-bootstrap'
import { Outlet } from 'react-router-dom'

function AppLayout() {
  const currentDate = new Date().toISOString().slice(0, 10)

  return (
    <Container className="app-shell py-3">
      <header className="app-header">
        <div className="fw-bold">Logo</div>
        <div className="fw-bold">Restaurant Management</div>
        <div>Date: {currentDate}</div>
      </header>
      <main className="content-box">
        <Outlet />
      </main>
      <footer className="mt-3">@2026 FPT University</footer>
    </Container>
  )
}

export default AppLayout
