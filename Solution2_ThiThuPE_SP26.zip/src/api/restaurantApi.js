import axios from 'axios'

const apiClient = axios.create({
  baseURL: 'http://localhost:8080/api',
})

export async function getCategories() {
  const response = await apiClient.get('/categories')
  return Array.isArray(response.data) ? response.data : []
}

export async function getRestaurants(params) {
  const requestParams = { ...params }
  if (typeof requestParams.page === 'number') {
    requestParams.page = requestParams.page + 1
  }
  const response = await apiClient.get('/restaurants', { params: requestParams })
  const data = response.data

  if (Array.isArray(data)) {
    return {
      records: data.map((item) => ({
        ...item,
        id: item.id ?? item.restaurantId,
      })),
      page: 0,
      totalPages: 1,
      totalElements: data.length,
    }
  }

  const records = (data.content ?? []).map((item) => ({
    ...item,
    id: item.id ?? item.restaurantId,
  }))
  const serverPageNumber = data.pageNumber ?? data.number
  const currentPage = typeof serverPageNumber === 'number' ? Math.max(serverPageNumber - 1, 0) : 0

  return {
    records,
    page: currentPage,
    totalPages: data.totalPages ?? 1,
    totalElements: data.totalElements ?? records.length,
  }
}

export async function getRestaurantDetail(id) {
  const response = await apiClient.get(`/restaurants/${id}`)
  return response.data
}

export async function createRestaurant(payload) {
  const response = await apiClient.post('/restaurants', payload)
  return response.data
}

export async function deleteRestaurant(id) {
  const response = await apiClient.delete(`/restaurants/${id}`)
  return response.data
}
