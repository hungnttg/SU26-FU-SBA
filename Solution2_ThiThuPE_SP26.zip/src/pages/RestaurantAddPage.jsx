import { useEffect, useMemo, useState } from 'react'
import { Alert, Button, Col, Form, Row } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { createRestaurant, getCategories } from '../api/restaurantApi'
import { MESSAGE } from '../constants/messages'

const PRICE_MIN = 1000
const PRICE_MAX = 999999

function isValidDateText(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false
  }
  const [yearText, monthText, dayText] = value.split('-')
  const year = Number(yearText)
  const month = Number(monthText)
  const day = Number(dayText)
  const date = new Date(year, month - 1, day)
  if (Number.isNaN(date.getTime())) {
    return false
  }
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day
}

function RestaurantAddPage() {
  const navigate = useNavigate()
  const [categories, setCategories] = useState([])
  const [serverMessage, setServerMessage] = useState('')
  const [serverMessageType, setServerMessageType] = useState('success')
  const [errors, setErrors] = useState({})
  const [form, setForm] = useState({
    restaurantName: '',
    priceFrom: '',
    priceTo: '',
    address: '',
    ownerName: '',
    categoryId: '',
    openDate: '',
  })

  useEffect(() => {
    async function loadCategories() {
      try {
        const data = await getCategories()
        setCategories(data)
      } catch {
        setServerMessageType('danger')
        setServerMessage(MESSAGE.MS05)
      }
    }
    loadCategories()
  }, [])

  const today = useMemo(() => new Date().toISOString().slice(0, 10), [])

  const onChangeField = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  const validate = () => {
    const nextErrors = {}

    if (!form.restaurantName.trim()) nextErrors.restaurantName = MESSAGE.MS01('Restaurant Name')
    if (!form.ownerName.trim()) nextErrors.ownerName = MESSAGE.MS01('Owner Name')
    if (!form.address.trim()) nextErrors.address = MESSAGE.MS01('Address')
    if (!form.categoryId) nextErrors.category = MESSAGE.MS01('Category')
    if (!form.openDate) {
      nextErrors.openDate = MESSAGE.MS01('Open Date')
    } else if (!isValidDateText(form.openDate)) {
      nextErrors.openDate = MESSAGE.MS03
    } else if (form.openDate > today) {
      nextErrors.openDate = 'The input date must not be in future'
    }

    const fromValue = Number(form.priceFrom)
    const toValue = Number(form.priceTo)

    if (!form.priceFrom) {
      nextErrors.priceFrom = MESSAGE.MS01('Price from')
    } else if (!Number.isInteger(fromValue) || fromValue < PRICE_MIN || fromValue > PRICE_MAX) {
      nextErrors.priceFrom = MESSAGE.MS02('Price from', PRICE_MIN, PRICE_MAX)
    }

    if (!form.priceTo) {
      nextErrors.priceTo = MESSAGE.MS01('Price to')
    } else if (!Number.isInteger(toValue) || toValue < PRICE_MIN || toValue > PRICE_MAX) {
      nextErrors.priceTo = MESSAGE.MS02('Price to', PRICE_MIN, PRICE_MAX)
    } else if (Number.isInteger(fromValue) && toValue <= fromValue) {
      nextErrors.priceTo = 'Price to must be greater than Price from'
    }

    setErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  const onSubmit = async (event) => {
    event.preventDefault()
    setServerMessage('')
    if (!validate()) {
      return
    }

    try {
      await createRestaurant({
        restaurantName: form.restaurantName.trim(),
        ownerName: form.ownerName.trim(),
        address: form.address.trim(),
        categoryId: Number(form.categoryId),
        priceFrom: Number(form.priceFrom),
        priceTo: Number(form.priceTo),
        openDate: form.openDate,
      })
      setServerMessageType('success')
      setServerMessage(MESSAGE.MS04)
      setForm({
        restaurantName: '',
        priceFrom: '',
        priceTo: '',
        address: '',
        ownerName: '',
        categoryId: '',
        openDate: '',
      })
      setErrors({})
    } catch (error) {
      if (error.response?.status === 400) {
        setServerMessageType('danger')
        setServerMessage('Restaurant name duplicated')
        return
      }
      setServerMessageType('danger')
      setServerMessage(MESSAGE.MS05)
    }
  }

  return (
    <>
      <h4 className="mb-3">Add New Restaurant</h4>
      {serverMessage && <Alert variant={serverMessageType}>{serverMessage}</Alert>}
      <Form onSubmit={onSubmit}>
        <Row className="mb-3">
          <Col md={3}>
            <Form.Label>Restaurant name:</Form.Label>
          </Col>
          <Col md={7}>
            <Form.Control
              maxLength={100}
              value={form.restaurantName}
              onChange={(e) => onChangeField('restaurantName', e.target.value)}
            />
            {errors.restaurantName && <div className="field-error">{errors.restaurantName}</div>}
          </Col>
        </Row>

        <Row className="mb-3">
          <Col md={3}>
            <Form.Label>Price from (d):</Form.Label>
          </Col>
          <Col md={3}>
            <Form.Control value={form.priceFrom} onChange={(e) => onChangeField('priceFrom', e.target.value)} />
            {errors.priceFrom && <div className="field-error">{errors.priceFrom}</div>}
          </Col>
          <Col md={1} className="d-flex align-items-center">
            To:
          </Col>
          <Col md={3}>
            <Form.Control value={form.priceTo} onChange={(e) => onChangeField('priceTo', e.target.value)} />
            {errors.priceTo && <div className="field-error">{errors.priceTo}</div>}
          </Col>
        </Row>

        <Row className="mb-3">
          <Col md={3}>
            <Form.Label>Address:</Form.Label>
          </Col>
          <Col md={7}>
            <Form.Control maxLength={100} value={form.address} onChange={(e) => onChangeField('address', e.target.value)} />
            {errors.address && <div className="field-error">{errors.address}</div>}
          </Col>
        </Row>

        <Row className="mb-3">
          <Col md={3}>
            <Form.Label>Owner name:</Form.Label>
          </Col>
          <Col md={7}>
            <Form.Control
              maxLength={100}
              value={form.ownerName}
              onChange={(e) => onChangeField('ownerName', e.target.value)}
            />
            {errors.ownerName && <div className="field-error">{errors.ownerName}</div>}
          </Col>
        </Row>

        <Row className="mb-3">
          <Col md={3}>
            <Form.Label>Category:</Form.Label>
          </Col>
          <Col md={3}>
            <Form.Select value={form.categoryId} onChange={(e) => onChangeField('categoryId', e.target.value)}>
              <option value="">Select category</option>
              {categories.map((category, index) => (
                <option
                  key={`${category?.categoryId ?? category?.id ?? index}-${index}`}
                  value={String(category?.categoryId ?? category?.id ?? '')}
                >
                  {category?.categoryName ?? category?.name ?? ''}
                </option>
              ))}
            </Form.Select>
            {errors.category && <div className="field-error">{errors.category}</div>}
          </Col>
          <Col md={2}>
            <Form.Label>Open Date:</Form.Label>
          </Col>
          <Col md={2}>
            <Form.Control type="date" value={form.openDate} onChange={(e) => onChangeField('openDate', e.target.value)} />
            {errors.openDate && <div className="field-error">{errors.openDate}</div>}
          </Col>
        </Row>

        <Row>
          <Col md={{ span: 7, offset: 3 }} className="d-flex gap-2">
            <Button type="submit">Save</Button>
            <Button variant="outline-secondary" onClick={() => navigate('/restaurants')}>
              Back
            </Button>
          </Col>
        </Row>
      </Form>
    </>
  )
}

export default RestaurantAddPage
