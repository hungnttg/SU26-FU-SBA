import { useEffect, useMemo, useState } from 'react'
import { Alert, Button, Col, Form, Modal, Pagination, Row, Spinner, Table } from 'react-bootstrap'
import { Link, useNavigate } from 'react-router-dom'
import { deleteRestaurant, getCategories, getRestaurants } from '../api/restaurantApi'
import { MESSAGE } from '../constants/messages'

const PAGE_SIZE = 5

function getCategoryLabel(category) {
  if (typeof category === 'string') {
    return category
  }
  return category?.categoryName ?? category?.name ?? ''
}

function getCategoryValue(category) {
  if (typeof category === 'string') {
    return ''
  }
  return String(category?.categoryId ?? category?.id ?? '')
}

function RestaurantListPage() {
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [categories, setCategories] = useState([])
  const [rows, setRows] = useState([])
  const [page, setPage] = useState(0)
  const [totalPages, setTotalPages] = useState(1)
  const [totalElements, setTotalElements] = useState(0)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [messageType, setMessageType] = useState('success')
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [selectedRestaurant, setSelectedRestaurant] = useState(null)

  const loadRestaurants = async (targetPage = 0) => {
    try {
      setLoading(true)
      setMessage('')
      const result = await getRestaurants({
        name: name.trim() || undefined,
        categoryId: selectedCategory || undefined,
        page: targetPage,
        size: PAGE_SIZE,
        sort: 'restaurantName,asc',
      })
      setRows(result.records)
      setPage(result.page)
      setTotalPages(result.totalPages || 1)
      setTotalElements(result.totalElements)
    } catch {
      setMessageType('danger')
      setMessage(MESSAGE.MS05)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    async function initData() {
      try {
        const categoryList = await getCategories()
        setCategories(categoryList)
      } catch {
        setMessageType('danger')
        setMessage(MESSAGE.MS05)
      }
      try {
        setLoading(true)
        const result = await getRestaurants({
          page: 0,
          size: PAGE_SIZE,
          sort: 'restaurantName,asc',
        })
        setRows(result.records)
        setPage(result.page)
        setTotalPages(result.totalPages || 1)
        setTotalElements(result.totalElements)
      } catch {
        setMessageType('danger')
        setMessage(MESSAGE.MS05)
      } finally {
        setLoading(false)
      }
    }
    initData()
  }, [])

  const startRecord = useMemo(() => (totalElements === 0 ? 0 : page * PAGE_SIZE + 1), [page, totalElements])
  const endRecord = useMemo(() => Math.min((page + 1) * PAGE_SIZE, totalElements), [page, totalElements])

  const onFilter = () => {
    loadRestaurants(0)
  }

  const openDelete = (restaurant) => {
    setSelectedRestaurant(restaurant)
    setShowDeleteModal(true)
  }

  const onDelete = async () => {
    if (!selectedRestaurant) {
      return
    }
    try {
      await deleteRestaurant(selectedRestaurant.id ?? selectedRestaurant.restaurantId)
      setShowDeleteModal(false)
      setSelectedRestaurant(null)
      setMessageType('success')
      setMessage(MESSAGE.MS08)
      await loadRestaurants(0)
    } catch {
      setShowDeleteModal(false)
      setMessageType('danger')
      setMessage(MESSAGE.MS05)
    }
  }

  return (
    <>
      <h4 className="mb-3">Restaurant List</h4>

      <Form className="mb-3">
        <Row className="g-3 align-items-end">
          <Col md={4}>
            <Form.Label>Category:</Form.Label>
            <Form.Select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
              <option value="">All</option>
              {categories.map((category, index) => (
                <option key={`${getCategoryValue(category)}-${index}`} value={getCategoryValue(category)}>
                  {getCategoryLabel(category)}
                </option>
              ))}
            </Form.Select>
          </Col>
          <Col md={4}>
            <Form.Label>Restaurant Name:</Form.Label>
            <Form.Control maxLength={100} value={name} onChange={(e) => setName(e.target.value)} />
          </Col>
          <Col md={4} className="d-flex gap-2 justify-content-md-end">
            <Button variant="outline-primary" onClick={onFilter}>
              Filter
            </Button>
            <Button onClick={() => navigate('/restaurants/new')}>Add New</Button>
          </Col>
        </Row>
      </Form>

      {message && (
        <Alert variant={messageType} className="py-2">
          {message}
        </Alert>
      )}

      <h5>Restaurant List</h5>

      {loading ? (
        <div className="text-center py-4">
          <Spinner />
        </div>
      ) : rows.length === 0 ? (
        <div className="py-3 fw-bold text-danger">No records found</div>
      ) : (
        <Table bordered striped>
          <thead>
            <tr>
              <th>#</th>
              <th>Restaurant Name</th>
              <th>Category</th>
              <th>Owner</th>
              <th>Address</th>
              <th>Price range(d)</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((restaurant, index) => (
              <tr key={restaurant.id ?? restaurant.restaurantId}>
                <td>{page * PAGE_SIZE + index + 1}</td>
                <td>{restaurant.restaurantName}</td>
                <td>{restaurant.categoryName ?? restaurant.category?.name ?? restaurant.category}</td>
                <td>{restaurant.ownerName}</td>
                <td>{restaurant.address}</td>
                <td>
                  {restaurant.priceFrom} - {restaurant.priceTo}
                </td>
                <td>
                  <Button size="sm" variant="link" className="p-0 me-2 text-danger" onClick={() => openDelete(restaurant)}>
                    Delete
                  </Button>
                  <Link to={`/restaurants/${restaurant.id ?? restaurant.restaurantId}`}>View</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      {totalPages > 1 && (
        <div className="d-flex justify-content-between align-items-center">
          <div>
            Show {startRecord} - {endRecord} of {totalElements} records
          </div>
          <Pagination className="mb-0">
            <Pagination.Prev disabled={page === 0} onClick={() => loadRestaurants(page - 1)} />
            {Array.from({ length: totalPages }, (_, index) => (
              <Pagination.Item key={index} active={index === page} onClick={() => loadRestaurants(index)}>
                {index + 1}
              </Pagination.Item>
            ))}
            <Pagination.Next disabled={page >= totalPages - 1} onClick={() => loadRestaurants(page + 1)} />
          </Pagination>
        </div>
      )}

      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Confirmation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete the restaurant "{selectedRestaurant?.restaurantName}"?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="danger" onClick={onDelete}>
            Yes
          </Button>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default RestaurantListPage
