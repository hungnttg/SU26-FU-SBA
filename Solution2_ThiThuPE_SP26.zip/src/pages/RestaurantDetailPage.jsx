import { useEffect, useState } from 'react'
import { Alert, Button, Spinner } from 'react-bootstrap'
import { useNavigate, useParams } from 'react-router-dom'
import { getRestaurantDetail } from '../api/restaurantApi'
import { MESSAGE } from '../constants/messages'

function RestaurantDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [restaurant, setRestaurant] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchDetail() {
      try {
        setLoading(true)
        const data = await getRestaurantDetail(id)
        setRestaurant(data)
      } catch {
        setError(MESSAGE.MS05)
      } finally {
        setLoading(false)
      }
    }
    fetchDetail()
  }, [id])

  return (
    <>
      <h4 className="mb-4">VIEW DETAILS</h4>
      {error && <Alert variant="danger">{error}</Alert>}
      {loading ? (
        <Spinner />
      ) : restaurant ? (
        <div className="detail-grid mb-4">
          <div>Restaurant Name:</div>
          <div>{restaurant.restaurantName}</div>
          <div>Owner Name:</div>
          <div>{restaurant.ownerName}</div>
          <div>Category:</div>
          <div>{restaurant.categoryName ?? restaurant.category?.name ?? restaurant.category}</div>
          <div>Price range (d):</div>
          <div>
            {restaurant.priceFrom} - {restaurant.priceTo}
          </div>
          <div>Address:</div>
          <div>{restaurant.address}</div>
          <div>Open Date:</div>
          <div>{restaurant.openDate}</div>
        </div>
      ) : null}
      <Button variant="outline-primary" onClick={() => navigate('/restaurants')}>
        Back
      </Button>
    </>
  )
}

export default RestaurantDetailPage
