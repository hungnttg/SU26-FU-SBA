import { Link } from "react-router-dom";
export default function Products(){
    //data
    const list=[
        {id:1,name:"Laptop HP"},
        {id:2,name:"Macbook Pro"},
        {id:3,name:"Asus Zenbook"}
    ];
    //giao dien
    return(
        <div className="container">
            <h2>Danh sach san pham</h2>
            <ul>
                {list.map(p=>(
                    <li key={p.id}>
                        <Link to={`/products/${p.id}`}>{p.name}</Link>
                    </li>
                ))}
            </ul>
        </div>
    );
}