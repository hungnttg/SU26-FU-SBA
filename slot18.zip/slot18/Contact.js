import { Link } from "react-router-dom";
export default function Contact(){
    return(
        <div className="container">
            <h2>Lien he</h2>
            <p>EMail: contact@gmail.com</p>
            <p>MObile: 0912345678</p>
        </div>
    );
}