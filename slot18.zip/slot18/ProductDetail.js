import { Link,useParams } from "react-router-dom";
export default function ProductDetail(){
    const {id}=useParams();
    return(
        <div className="container">
            <h2>Chi tiet san pham</h2>
            <p>ID san pham: {id}</p>
        </div>
    );
}