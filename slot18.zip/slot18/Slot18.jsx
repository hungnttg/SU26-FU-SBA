//npm i react-router-dom
import "./Slot18.css";
import { Link,Route,BrowserRouter as Router,Routes } from "react-router-dom";
import Home from "./Home";
import About from "./About";
import Contact from "./Contact";
import Products from "./Products";
import ProductDetail from "./ProductDetail";
import Posts from "./Posts";
import PostDetail from "./PostDetail";
export default function Slot18(){
    return(
        <Router>
            <nav>
                <Link to={"/"}>Home</Link>
                <Link to={"/about"}>About</Link>
                <Link to={"/contact"}>COntact</Link>
                <Link to={"/products"}>List product</Link>
                <Link to={"/posts"}>Posts</Link>
            </nav>
            <Routes>
                <Route path="/" element={<Home/>} />
                <Route path="/about" element={<About/>} />
                <Route path="/contact" element={<Contact/>} />
                <Route path="/products" element={<Products/>}/>
                <Route path="/products/:id" element={<ProductDetail/>} />
                <Route path="/posts" element={<Posts/>} />
                <Route path="/posts/:id" element={<PostDetail/>} />
            </Routes>
        </Router>
    );
}