import { data, Link,useParams } from "react-router-dom";
import { useEffect,useState } from "react";
export default function PostDetail(){
    //code
    const {id}=useParams();//lay id tu listproduct chuyen sang detail
    const [post,setPost]=useState(null);
    //hien thi
    useEffect(()=>{
        fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
        .then(res=>res.json())
        .then(data=>setPost(data));
    },[id]);
    if(!post) return <p>Dang tai bai viet...</p>
    //layout
    return(
        <div className="card">
            <h2>{post.title}</h2>
            <p>{post.body}</p>
        </div>
    );
}