import React from "react";
export default function Header(){
    return(
        <header className="header">
            <h1>My Reacy Application</h1>
        </header>
    );
}