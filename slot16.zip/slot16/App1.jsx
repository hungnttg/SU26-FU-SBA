import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Content1 from "./Content1";
import Content2 from "./Content2";
import "./App1.css";

export default function App1(){
    return(
        <div className="app-container">
            <Header/>
            <main className="main-content">
                <Content1/>
                <Content2/>
            </main>
            <Footer/>
        </div>
    );
}