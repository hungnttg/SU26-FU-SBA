import React from "react";
export default function Footer(){
    return(
        <footer className="footer">
            <p>&copy; 2026 My APp. All rights reserved</p>
        </footer>
    );
}