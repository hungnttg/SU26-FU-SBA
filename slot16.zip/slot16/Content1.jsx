import React,{useEffect,useState} from "react";
export default function Content1(){
    //-------------------code---------------------------
    const [products,setProducts]=useState([]);
    const [visible,setVisible]=useState(6);//so san pham hien thi ban dau
    useEffect(()=>{
        fetch("https://hungnttg.github.io/shopgiay.json")
        .then((res)=>res.json())
        .then((data)=>{
            if(data && Array.isArray(data.products)){
                setProducts(data.products);
            }
            else {
                console.error("API khong tra ve mang products: ",data);
            }
        })
        .catch((err)=>console.error("Error fetching data: ",err));
    },[]);
    const loadMore = () =>setVisible((prev)=>prev+6);//ham loadmore
    //-------------------layout--------------------------
    return(
        <section  className="content-box">
            <h2>Content Section 1</h2>
            <div className="grid">
                {Array.isArray(products) &&
                    products.slice(0,visible).map((item)=>(
                        <div key={item.styleid} className="card">
                            <img src={item.search_image} />
                            <h3>{item.brands_filter_facet}</h3>
                            <p>{item.product_additional_info}</p>
                            <p><strong>Price: </strong>{item.price}</p>
                        </div>
                    ))
                }
            </div>
            {Array.isArray(products) && visible < products.length && (
                <button className="load-more" onClick={loadMore}>Load More...</button>
            )}
            {/* viet css truc tiep */}
            <style>{`
                .grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px,1fr));
    gap: 15px;
    margin-top: 15px;
}
.card {
    background-color: #fff;
    border-radius: 10px;
    overflow: hidden;
    text-align: center;
    transition: transform 0.3s, box-shadow 0.3s;
    cursor: pointer;
    padding: 12px;
}
.card:hover {
    transform: translate(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
}
.card img {
    width: 100%;
    max-height: 120px;
    object-fit: contain;
    border-radius: 6px;
    margin-bottom: 8px;
    transition: transform 0.3s;
}
                
            `}</style>
        </section>
    );
}