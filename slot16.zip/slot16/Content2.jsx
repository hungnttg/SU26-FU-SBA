import React,{useState,useEffect} from "react";
export default function Content2(){
    //code--------------------------------------
    const [posts,setPosts]=useState([]);
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/posts")
        .then((res)=>res.json())
        .then((data)=>setPosts(data.slice(0,5)))//lay 5 bai viet
        .catch((err)=>console.error("Error fetching posts: ",err));
    },[]);
    //layout-------------------------------------
    return(

        <section>
            <h2>Content Section 2</h2>
            <ul className="post-line">
                {posts.map((post)=>(
                    <li key={post.id} className="post-item">
                        <h3>{post.title}</h3>
                        <p>{post.body}</p>
                    </li>
                ))}
            </ul>
        </section>
    );
}