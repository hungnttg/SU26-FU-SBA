import Card from "./Slot3_2_Con";
export default function Slot3_2_Cha(){
    return(
        <div>
            <h1>Demo Children props</h1>
            <Card>
                <p>Noi dung ben trong the Card</p>
            </Card>
            <Card>
                <button>Bam vao day</button>
            </Card>
        </div>
    );
}