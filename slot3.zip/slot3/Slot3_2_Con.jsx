export default function Card({children}){
    return(
        <div style={{border:"1px solid gray",padding:"10px", margin:"10px"}}>
            {children}
        </div>
    );
}