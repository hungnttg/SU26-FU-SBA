//import thanh phan con
import Slot3_1_Con from "./Slot3_1_Con";
export default function Slot3_1_Cha(){
    return(
        <div>
            <h1>Demo props</h1>
            {/* goi component con va truyen tham so */}
            <Slot3_1_Con name="An" age={21}/>
            <Slot3_1_Con name="Binh" age={20}/>
        </div>
    );
}