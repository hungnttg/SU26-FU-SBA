export default function Slot3_3(){
    //khai bao 1 mang
    const students = [
        {id:1,name:"an",age:21},
        {id:2,name:"binh",age:22},
        {id:3,name:"chung",age:20}
    ];
    return(
        <div>
            <h1>Danh sach sinh vien</h1>
            {students.map((s)=>(
                <div key={s.id}>
                    <p>{s.name} - {s.age} tuoi </p>
                </div>
            ))}
        </div>
    );
}