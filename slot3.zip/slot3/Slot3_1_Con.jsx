export default function Slot3_1_Con({name,age}){
    return(
        <div>
            <p>Ho ten: {name}</p>
            <p>Tuoi: {age}</p>
        </div>
    );
}