import Product from "./Slot3_4_Con";
export default function Slot3_4_Cha(){
    //doc du lieu tu API hoac tao mang
    const products = [
        {id:1,name:"Laptop",price:15000000,desc:"Laptop gaming"},
        {id:2,name:"Dien thoai",price:8000000,desc:"Smartphone"},
    ];
    return(
        <div>
            <h1>Sanh sach san pham</h1>
            {products.map((p)=>(
                <Product key={p.id} name={p.name} price={p.price} desc={p.desc}/>
            ))}
        </div>
    );
}