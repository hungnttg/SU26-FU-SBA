export default function Product({name,price,desc}){
    return(
        <div style={{border:"1px solid blue",padding:"10px",margin:"10px"}}>
            <h3>{name}</h3>
            <p>Gia: {price} VND</p>
            <p>{desc}</p>
        </div>
    );
}