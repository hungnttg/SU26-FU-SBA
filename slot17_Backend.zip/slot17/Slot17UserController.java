package com.example.demo.slot17;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/slot17") //tien to cho tat ca cac enpoint
@CrossOrigin(origins = "http://localhost:3000")
public class Slot17UserController {
    private static Map<Long,Slot17User> users = new HashMap<>();
    static {
        users.put(1L,new Slot17User(1L,"An","an@gmail.com"));
        users.put(2L,new Slot17User(2L,"Binh","binh@gmail.com"));
    }
    //danh sach user voi HATEOAS _links
    @GetMapping("/users")
    public List<Map<String,Object>> getUsers(){
        List<Map<String, Object>> result = new ArrayList<>();
        for(Slot17User u: users.values()){
            Map<String,Object> m=new HashMap<>();
            m.put("id",u.getId());
            m.put("name",u.getName());
            m.put("email",u.getEmail());
            Map<String,String> links = new HashMap<>();
            //URL day du voi tien to slot17
            links.put("self","http://localhost:8080/slot17/users/"+u.getId());
            m.put("_links",links);
            result.add(m);
        }
        return result;
    }
    //chi tiet user
    @GetMapping("/users/{id}")
    public Slot17User getUser(@PathVariable Long id){
        return users.get(id);
    }
}
//GET: http://localhost:8080/slot17/users
//client: cos the dung _links.self.href de dieu huong toi chi tiet user ma khong can biet URL
