package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
    @Autowired
    private UserService service;
    @GetMapping("/{id}")
    public User getById(@PathVariable String id){
        return service.getById(id).orElse(null);
    }
    @GetMapping
    public List<User> getAll(){
        return service.getAll();
    }
    @PostMapping
    public User create(@RequestBody User u){
        return service.create(u);
    }
    @PutMapping("/{id}")
    public User update(@PathVariable String id,@RequestBody User u){
        return service.update(id,u);
    }
    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id){
        service.delete(id);
        return "Deleted id= "+id;
    }
}
