package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository repo;
    public List<User> getAll(){
        return repo.findAll();
    }
    public Optional<User> getById(String id){
        return repo.findById(id);

    }
    public User create(User u){
        return repo.save(u);
    }
    public User update(String id,User u){
        return repo.findById(id).map(user->{
            user.setName(u.getName());
            user.setBirthday(u.getBirthday());
            return repo.save(user);
        }).orElse(null);
    }
    public void delete(String id){
        repo.deleteById(id);
    }
}
