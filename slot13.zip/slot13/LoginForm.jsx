import "../slot13/LoginForm.scss";
export default function LoginForm(){
    //code
    //layout
    return(
        <div className="login">
            <div className="login-card">
                <h1 className="login-title">Login</h1>
                <input
                    className="login-input"
                    type="text"
                    placeholder="Username"
                />
                <input
                    className="login-input"
                    type="password"
                    placeholder="Password"
                />
                <button className="login-button">
                    Sign In
                </button>
            </div>
        </div>
    );
}