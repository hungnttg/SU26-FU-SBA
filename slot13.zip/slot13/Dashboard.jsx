import "../slot13/Dashboard.scss";
export default function Dashboard(){
    return(
        <div className="dashboard">
            <aside className="dashboard-sidebar">
                <h2 className="dashboard-logo">
                    ADMIN PANEL
                </h2>
                <ul className="dashboard-menu">
                    <li>Dashboard</li>
                    <li>Users</li>
                    <li>Products</li>
                    <li>Settings</li>
                </ul>
            </aside>
            <main className="dashboard-content">
                <div className="dashboard-card">
                    <h3>Total Users</h3>
                    <p>1250</p>
                </div>
                <div className="dashboard-card">
                    <h3>Total Orders</h3>
                    <p>520</p>
                </div>
                <div className="dashboard-card">
                    <h3>Revenue</h3>
                    <p>100000000d</p>
                </div>
            </main>
        </div>
    );
}