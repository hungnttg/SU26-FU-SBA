export default function Slot2_2(){
    //code=============
    //khai bao doi tuong sinh vien
    const student = {name:"An",age:21};
    //layout===================
    return(
        <div>
            <h1>Demo 22</h1>
            <p>Ten sinh vien: {student.name}</p>
            <p>Tuoi: {student.age}</p>
            <p>Tinh toan: {3+5}</p>
            <p>Dieu kien: {student.age > 20 ? "Tren 20 tuoi":"Duoi 20 tuoi"}</p>
        </div>
    );
}