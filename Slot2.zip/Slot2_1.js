//su dung props va state
import { useState } from "react";
import Slot1_2 from "./SLot1_2";
export default function Slot2_1(){
    //code=====================
    //khai bao bien count de quan ly trang thai: dem so lan click
    const [count,setCount]=useState(0);
    //count: bien; setCount: phuong thuc thay doi du lieu;
    //0 la gia tri khoi tao
    //layout====================
    return(
        <div>
            <h1>Xin chao React</h1>
            {/* goi component trong component */}
            <Slot1_2 name="An"/>
            {/* goi bien: {} */}
            <p>Ban da bam click {count} lan</p>
            {/* su kien thay doi bien */}
            <button onClick={()=>setCount(count+1)}>Click1</button>
            
        </div>
    );
}