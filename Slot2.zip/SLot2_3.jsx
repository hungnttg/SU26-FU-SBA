//xu ly su kien
import { useState } from "react";
export default function Slot2_3(){
    //code=============
        const [count,setCount]=useState(0);
        const handleClick = () =>{
            setCount(count+1);
        };
    //layout==============
    return(
        <div>
            <h1>Xu ly su kien</h1>
            <p>Ban click {count} lan</p>
            <button onClick={handleClick}>Click me</button>
        </div>
    );
}