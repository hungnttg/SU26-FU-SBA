//bai toan nhap lieu
import { useState } from "react";
export default function Slot2_4(){
    //---code---------------------
    const [name,setName]=useState("");
    //----layout------------------
    return(
        <div>
            <h1>2. cach gan du lieu</h1>
            <input
                style={{borderWidth:1}}
                type="text"
                placeholder="nhap ten"
                value={name}
                onChange={(e)=>setName(e.target.value)}
            />
            <p>Ban vu nhap: {name}</p>
        </div>
    );
}