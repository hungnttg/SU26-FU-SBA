package com.example.demo.slot21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slot21Application {
    public static void main(String[] args) {
        SpringApplication.run(Slot21Application.class,args);
    }
}
