package com.example.demo.slot21;

import org.springframework.web.bind.annotation.*;

import  java.util.List;
@RestController
@RequestMapping("/slot21/products")
@CrossOrigin(origins = "http://localhost:3001")
public class Slot21ProductController {
    private final Slot21ProductRepository repo;
    public Slot21ProductController(Slot21ProductRepository repo){
        this.repo = repo;
    }
    @GetMapping
    public List<Slot21Product> getAll(){
        return repo.findAll();
    }
    @PostMapping
    public Slot21Product add(@RequestBody Slot21Product p){
        return repo.save(p);
    }
    @PutMapping("/{id}")
    public Slot21Product update(@PathVariable Long id,@RequestBody Slot21Product p){
        p.setId(id);
        return repo.save(p);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id){
        repo.deleteById(id);
    }
}
