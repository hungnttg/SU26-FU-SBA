//su dung props co ban
export default function Slot1_2(props){
    //code============
    //layout=============
    return(
        <h2>Xin chao, {props.name} </h2>
    );
}
// cach trieu goi bien: {}
//o doan code tren, thuoc tinh can truyen la: name
