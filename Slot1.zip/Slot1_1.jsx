export default function Slot1_1(){
    //code
    //layout
    return(
        <div>
            <h1>Hello react</h1>
            <p>Day la ung dung React dau tien</p>
        </div>
    );
}