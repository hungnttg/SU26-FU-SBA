import React, { useState } from "react";

function AddProduct({ onAdded }) {
  // state form
  const [form, setForm] = useState({
    tensanpham: "",
    giasanpham: "",
    hinhanhsanpham: "",
    motasanpham: "",
    idsanpham: ""
  });

  // lay du lieu tu input
  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  // submit form
  const submit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(
        "http://localhost:8080/api/products",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            tensanpham: form.tensanpham,
            giasanpham: parseInt(form.giasanpham || 0),
            hinhanhsanpham: form.hinhanhsanpham,
            motasanpham: form.motasanpham,
            idsanpham: parseInt(form.idsanpham || 0)
          })
        }
      );

      if (!response.ok) {
        throw new Error("Them san pham that bai");
      }

      // goi ham reload tu component cha
      onAdded();

      // reset form
      setForm({
        tensanpham: "",
        giasanpham: "",
        hinhanhsanpham: "",
        motasanpham: "",
        idsanpham: ""
      });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <form onSubmit={submit} style={{ marginBottom: 20 }}>
      <input
        name="tensanpham"
        placeholder="Ten san pham"
        value={form.tensanpham}
        onChange={handleChange}
        required
      />

      <input
        name="giasanpham"
        type="number"
        placeholder="Gia san pham"
        value={form.giasanpham}
        onChange={handleChange}
        required
      />

      <input
        name="hinhanhsanpham"
        placeholder="Hinh anh"
        value={form.hinhanhsanpham}
        onChange={handleChange}
        required
      />

      <input
        name="motasanpham"
        placeholder="Mo ta"
        value={form.motasanpham}
        onChange={handleChange}
        required
      />

      <input
        name="idsanpham"
        type="number"
        placeholder="ID san pham"
        value={form.idsanpham}
        onChange={handleChange}
        required
      />

      <button type="submit">
        Them san pham
      </button>
    </form>
  );
}

export default AddProduct;