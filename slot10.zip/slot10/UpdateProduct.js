import React,{useState,useEffect} from "react";
function UpdateProduct({product,onUpdated}){
    //======================code================
    const [form,setForm]=useState({
        tensanpham:"",
        giasanpham:"",
        hinhanhsanpham:"",
        motasanpham:"",
        idsanpham:""
    });
    //khi product thay doi => do du lieu len form
    useEffect(()=>{
        if(product){
            setForm({
                tensanpham: product.tensanpham || "",
                giasanpham: product.giasanpham || "",
                hinhanhsanpham: product.hinhanhsanpham || "",
                motasanpham: product.motasanpham || "",
                idsanpham: product.idsanpham || ""
            });
        }
    },[product]);
    //xu ly update
    const submit = async (e) =>{
        e.preventDefault();//chong submit gia tri mac dinh
        try {
            await fetch(`http://localhost:8080/api/products/${product.id}`,{
                method:"PUT",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify({
                    tensanpham: form.tensanpham,
                    giasanpham: parseInt(form.giasanpham || 0),
                    hinhanhsanpham: form.hinhanhsanpham,
                    motasanpham: form.motasanpham,
                    idsanpham: parseInt(form.idsanpham || 0)
                })
            });
            onUpdated();
        } catch (error) {
            console.error(error);
        }
    };
    //xu ly input
    const handleChange = (e) => {
        setForm({
            ...form, [e.target.name]: e.target.value
        });
    } ;

    //----------------------layout===============
    return(
        <form onSubmit={submit} style={{marginBottom:20}}>
            <h2>Cap nhat san pham</h2>
            <input
                name="tensanpham"
                placeholder="ten san pham"
                value={form.tensanpham}
                onChange={handleChange}
                required
            />
            <input
                name="giasanpham"
                placeholder="gia san pham"
                type="number"
                value={form.giasanpham}
                onChange={handleChange}
                required
            />
            <input
                name="hinhanhsanpham"
                placeholder="hinh anh san pham"
                value={form.hinhanhsanpham}
                onChange={handleChange}
                required
            />
            <input
                name="motasanpham"
                placeholder="mo ta san pham"
                value={form.motasanpham}
                onChange={handleChange}
                required
            />
            <input
                name="idsanpham"
                placeholder="id san pham"
                type="number"
                value={form.idsanpham}
                onChange={handleChange}
                required
            />
            <button type="submit">Cap nhat</button>
        </form>
    );
}
export default UpdateProduct;