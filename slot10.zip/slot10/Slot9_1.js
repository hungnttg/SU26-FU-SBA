//hien thi danh sach san pham
import React,{useEffect,useState} from "react";
import AddProduct from "./AddProduct";
import UpdateProduct from "./UpdateProduct";
export default function Slot9_1(){
    //code==============================================================================
    const [products, setProducts]=useState([]);//mang luu tru san pham
    const [loading,setLoading]=useState(true);//hien thi trang thai loading
    const [selectedProduct,setSelectedProduct]=useState(null);//dung de update
    //ham doc du lieu tu API
    const fetchProduct = () =>{
        fetch("http://localhost:8080/api/products") //doc du lieu
        .then(res=>res.json()) //chuyen du lieu sang json
        .then(data =>{
            setProducts(data);//dua du lieu doc duoc tu server vao mang
            setLoading(false);//doc xong thi doi trang thai loading
        })
        .catch(console.error);
    };
    //goi ham doc du lieu trong useEffect
    useEffect(()=>fetchProduct(),[]);
    //ham xoa san pham
    const deleteProduct = (id) =>{
        fetch(`http://localhost:8080/api/products/${id}`,{method:'DELETE'}) //thuc hien xoa
        .then(()=>fetchProduct()) //load du lieu con lai sau khi xoa
        .catch(console.error);//xu ly loi
    };  
    //quan ly trang thai loading
    if(loading) return <div>Dang tai....</div>;

    //layout==============================================================================
    return(
        <div style={{padding:20}}>
            <h1>Danh sach san pham</h1>
            <AddProduct onAdded={fetchProduct}/>
            <UpdateProduct
                product={selectedProduct}
                onUpdated={()=>{
                    fetchProduct();
                    setSelectedProduct(null)
                }}
            />
            <div style={{display:"flex",flexWrap:"wrap"}}>
                {/* hien thi san pham */}
                {products.map(p=>(
                    <div key={p.id} style={{width: 250,border:"1px solid #ddd",borderRadius:5,padding:10, margin:8}}>
                        <img src={p.hinhanhsanpham} style={{width:"100%",height:150,objectFit:"cover"}}/>
                        <h3>{p.tensanpham}</h3>    
                        <p>Gia: {p.giasanpham} VND</p>
                        <p>{p.motasanpham && p.motasanpham.slice(0,80)}...</p>
                        <button onClick={()=>deleteProduct(p.id)} style={{background:"red",color:"white"}}>Xoa</button>
                        <button onClick={()=>setSelectedProduct(p)} >
                            Sua
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
}