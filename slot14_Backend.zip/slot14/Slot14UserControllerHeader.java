package com.example.demo.slot14;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/slot14/users")
@CrossOrigin(origins = "http://localhost:3000")//cho phep react ket nooi
public class Slot14UserControllerHeader {
    @GetMapping(headers = "X-API-VERSION=1")
    public List<Slot14User> getUsersV1(){
        return Arrays.asList(new Slot14User(1L,"An","an@gmail.com"),
                new Slot14User(2L,"Binh","binh@gmail.com"));
    }
    @GetMapping(headers = "X-API-VERSION=2")
    public List<Slot14User> getUsersV2(){
        return Arrays.asList(new Slot14User(1L,"An","AN@GMAIL.COM"),
                new Slot14User(2L,"Binh","BINH@GMAIL.COM"));
    }
}
