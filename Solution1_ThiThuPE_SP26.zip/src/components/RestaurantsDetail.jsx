import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { getRestaurantsById } from '../api/restaurantsApi';

function RestaurantsDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [restaurants, setRestaurants] = useState(null);

  useEffect(() => {
    getRestaurantsById(id).then(res => setRestaurants(res.data)).catch(() => navigate('/'));
  }, [id, navigate]);

  if (!restaurants) return <p>Loading...</p>;

  const formatDate = (d) => {
    if (!d) return '';
    if (typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d)) {
      const [yyyy, mm, dd] = d.split('-');
      return `${dd}/${mm}/${yyyy}`;
    }
    const date = new Date(d);
    if (Number.isNaN(date.getTime())) return '';
    return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`;
  };

  return (
    <Container className="mt-3">
      <h4><strong>VIEW DETAILS</strong></h4>
      <Row className="mt-4">
        <Col md={{ span: 6, offset: 2 }}>
          <table>
            <tbody>
              <tr>
                <td className="pe-4 py-2 text-end"><strong>Restaurant Name:</strong></td>
                <td>{restaurants.restaurantName}</td>
              </tr>
              <tr>
                <td className="pe-4 py-2 text-end"><strong>Owner:</strong></td>
                <td>{restaurants.ownerName}</td>
              </tr>
              <tr>
                <td className="pe-4 py-2 text-end"><strong>Type:</strong></td>
                <td>{restaurants.categoryName}</td>
              </tr>
              <tr>
                <td className="pe-4 py-2 text-end"><strong>Price:</strong></td>
                <td>{restaurants.priceFrom} - {restaurants.priceTo}</td>
              </tr>
              <tr>
                <td className="pe-4 py-2 text-end"><strong>Open date:</strong></td>
                <td>{formatDate(restaurants.openDate)}</td>
              </tr>
              <tr>
                <td className="pe-4 py-2 text-end"><strong>Address:</strong></td>
                <td>{restaurants.address}</td>
              </tr>
            </tbody>
          </table>
          <Button variant="outline-dark" className="mt-3" onClick={() => navigate('/')}>
            Quay lại
          </Button>
        </Col>
      </Row>
    </Container>
  );
}

export default RestaurantsDetail;
