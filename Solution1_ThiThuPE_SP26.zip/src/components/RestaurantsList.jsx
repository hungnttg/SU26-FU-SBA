import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Table, Button, Form, Row, Col, Modal, Pagination, Alert, Container } from 'react-bootstrap';
import { getAllRestaurants, searchRestaurants, deleteRestaurants, getCategories } from '../api/restaurantsApi';

function RestaurantsList() {
  const navigate = useNavigate();
  const [restaurants, setRestaurants] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filterCategoryId, setFilterCategoryId] = useState('');
  const [filterName, setFilterName] = useState('');
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [showConfirm, setShowConfirm] = useState(false);
  const [selectedRestaurants, setSelectedRestaurants] = useState(null);
  const [message, setMessage] = useState('');

  const pageSize = 5;

  const loadRestaurants = async (p = 0) => {
    try {
      const res = await getAllRestaurants(p, pageSize);
      setRestaurants(res.data.content);
      setTotalPages(res.data.totalPages);
      setPage(p);
    } catch {
      setRestaurants([]);
    }
  };

  const loadCategories = async () => {
    try {
      const res = await getCategories();
      setCategories(res.data);
    } catch {
      setCategories([]);
    }
  };

  useEffect(() => {
    const init = async () => {
      await loadRestaurants();
      await loadCategories();
    };
    init();
  }, []);

  const handleFilter = async () => {
    try {
      const res = await searchRestaurants(filterName || null, filterCategoryId || null, 0, pageSize);
      setRestaurants(res.data.content);
      setTotalPages(res.data.totalPages);
      setPage(0);
    } catch {
      setRestaurants([]);
    }
  };

  const handleDelete = (item) => {
    setSelectedRestaurants(item);
    setShowConfirm(true);
  };

  const confirmDelete = async () => {
    try {
      await deleteRestaurants(selectedRestaurants.restaurantId);
      setShowConfirm(false);
      setMessage('Deleted successfully');
      setTimeout(() => setMessage(''), 3000);
      loadRestaurants(page);
    } catch {
      setShowConfirm(false);
    }
  };

  const handlePageChange = (p) => {
    if (filterName || filterCategoryId) {
      searchRestaurants(filterName || null, filterCategoryId || null, p, pageSize).then(res => {
        setRestaurants(res.data.content);
        setTotalPages(res.data.totalPages);
        setPage(p);
      });
    } else {
      loadRestaurants(p);
    }
  };

  const today = new Date();
  const dateStr = `${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`;

  return (
    <Container>
      <Row className="align-items-center mb-3 mt-2">
        <Col><strong>Logo</strong></Col>
        <Col className="text-end">Date: {dateStr}</Col>
      </Row>

      <h4>Restaurants List</h4>

      {message && <Alert variant="success">{message}</Alert>}

      <Row className="mb-3 align-items-end">
        <Col md={3}>
          <Form.Label>Category:</Form.Label>
          <Form.Select value={filterCategoryId} onChange={(e) => setFilterCategoryId(e.target.value)}>
            <option value="">All</option>
            {categories.map(c => (
              <option key={c.categoryId} value={c.categoryId}>{c.categoryName}</option>
            ))}
          </Form.Select>
        </Col>
        <Col md={5}>
          <Form.Label>Restaurants Name:</Form.Label>
          <Form.Control
            type="text"
            value={filterName}
            onChange={(e) => setFilterName(e.target.value)}
          />
        </Col>
        <Col md={4} className="d-flex gap-2">
          <Button variant="primary" onClick={handleFilter}>Filter</Button>
          <Button variant="success" onClick={() => navigate('/add')}>Add New</Button>
        </Col>
      </Row>

      <h5>Restaurants List</h5>
      {restaurants.length === 0 ? (
        <Alert variant="warning">No records found</Alert>
      ) : (
        <Table bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>Restaurant Name</th>
              <th>Category</th>
              <th>Owner</th>
              <th>Price</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {restaurants.map((s, i) => (
              <tr key={s.restaurantId}>
                <td>{page * pageSize + i + 1}</td>
                <td>{s.restaurantName}</td>
                <td>{s.categoryName}</td>
                <td>{s.ownerName}</td>
                <td>{s.priceFrom} - {s.priceTo}</td>
                <td>
                  <a href="#" className="text-danger me-2" onClick={(e) => { e.preventDefault(); handleDelete(s); }}>Delete</a>
                  {' | '}
                  <a href="#" className="text-primary" onClick={(e) => { e.preventDefault(); navigate(`/view/${s.restaurantId}`); }}>View</a>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      {totalPages > 1 && (
        <div className="d-flex justify-content-between align-items-center">
          <span>Hien thi {restaurants.length} tren {totalPages * pageSize}</span>
          <Pagination>
            <Pagination.Prev disabled={page === 0} onClick={() => handlePageChange(page - 1)}>
              Truoc
            </Pagination.Prev>
            {[...Array(totalPages)].map((_, i) => (
              <Pagination.Item key={i} active={i === page} onClick={() => handlePageChange(i)}>
                {i + 1}
              </Pagination.Item>
            ))}
            <Pagination.Next disabled={page === totalPages - 1} onClick={() => handlePageChange(page + 1)}>
              Sau
            </Pagination.Next>
          </Pagination>
        </div>
      )}

      <Modal show={showConfirm} onHide={() => setShowConfirm(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Confirmation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete restaurants "{selectedRestaurants?.restaurantName}"?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={confirmDelete}>Yes</Button>
          <Button variant="secondary" onClick={() => setShowConfirm(false)}>Close</Button>
        </Modal.Footer>
      </Modal>

      <hr />
      <footer className="text-center">@2026 FPT University</footer>
    </Container>
  );
}

export default RestaurantsList;
