import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Form, Button, Row, Col, Alert } from 'react-bootstrap';
import { createRestaurants, getCategories, searchRestaurants } from '../api/restaurantsApi';

function AddRestaurants() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({
    restaurantName: '',
    priceFrom: '',
    priceTo: '',
    ownerName: '',
    openDate: '',
    address: '',
    categoryId: '',
  });
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');

  useEffect(() => {
    getCategories().then(res => setCategories(res.data)).catch(() => {});
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: '' });
  };

  const toApiDate = (dateStr) => {
    if (!dateStr) return null;
    const parts = dateStr.split('/');
    if (parts.length !== 3) return null;
    const [dd, mm, yyyy] = parts;
    const ddNum = Number(dd);
    const mmNum = Number(mm);
    const yyyyNum = Number(yyyy);
    if (![ddNum, mmNum, yyyyNum].every(Number.isFinite)) return null;
    const date = new Date(Date.UTC(yyyyNum, mmNum - 1, ddNum));
    if (Number.isNaN(date.getTime())) return null;
    if (date.getUTCFullYear() !== yyyyNum || date.getUTCMonth() !== mmNum - 1 || date.getUTCDate() !== ddNum) return null;
    return `${yyyyNum}-${String(mmNum).padStart(2, '0')}-${String(ddNum).padStart(2, '0')}`;
  };

  const validate = async () => {
    const errs = {};

    if (!form.restaurantName.trim()) {
      errs.restaurantName = 'Restaurant name is required';
    } else if (form.restaurantName.length > 100) {
      errs.restaurantName = 'Restaurant name must be at most 100 characters';
    } else {
      try {
        const res = await searchRestaurants(form.restaurantName.trim(), null, 0, 100);
        const dup = res.data.content?.some(
          (s) => (s.restaurantName || '').toLowerCase() === form.restaurantName.trim().toLowerCase(),
        );
        if (dup) errs.restaurantName = 'Restaurant name already exists';
      } catch { }
    }

    const pFrom = Number(form.priceFrom);
    const pTo = Number(form.priceTo);

    if (!form.priceFrom) {
      errs.priceFrom = 'Price from is required';
    } else {
      if (Number.isNaN(pFrom) || pFrom <= 1000) errs.priceFrom = 'Price from must be greater than 1000';
    }

    if (!form.priceTo) {
      errs.priceTo = 'Price to is required';
    } else {
      if (Number.isNaN(pTo) || pTo <= 1000) errs.priceTo = 'Price to must be greater than 1000';
    }

    if (!errs.priceFrom && !errs.priceTo && pTo < pFrom) {
      errs.priceTo = 'Price to must be greater than or equal to price from';
    }

    if (!form.ownerName.trim()) {
      errs.ownerName = 'Owner name is required';
    } else if (form.ownerName.length > 100) {
      errs.ownerName = 'Owner name must be at most 100 characters';
    }

    const dateRegex = /^\d{1,2}\/\d{1,2}\/\d{4}$/;

    if (!form.openDate) {
      errs.openDate = 'Open date is required';
    } else if (!dateRegex.test(form.openDate) || toApiDate(form.openDate) === null) {
      errs.openDate = 'Format must be dd/MM/yyyy';
    }

    if (!form.categoryId) {
      errs.categoryId = 'Category is required';
    } else {
      const cid = Number(form.categoryId);
      if (Number.isNaN(cid) || cid <= 0) errs.categoryId = 'Category ID must be a positive number';
    }

    if (form.address && form.address.length > 100) {
      errs.address = 'Address must not exceed 100 characters';
    }

    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    const errs = await validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    try {
      await createRestaurants({
        restaurantName: form.restaurantName.trim(),
        priceFrom: Number(form.priceFrom),
        priceTo: Number(form.priceTo),
        ownerName: form.ownerName.trim(),
        openDate: toApiDate(form.openDate),
        address: form.address.trim(),
        categoryId: Number(form.categoryId),
      });
      setMessage('Created new restaurants successfully');
      setTimeout(() => navigate('/'), 1500);
    } catch {
      setMessage('Failed to create restaurants');
    }
  };

  const today = new Date();
  const dateStr = `${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`;

  return (
    <Container className="mt-2">
      <Row className="align-items-center mb-3">
        <Col><strong>Logo</strong></Col>
        <Col className="text-end">Date: {dateStr}</Col>
      </Row>

      <h4>Add New Restaurants</h4>

      {message && <Alert variant={message.includes('success') ? 'success' : 'danger'}>{message}</Alert>}

      <Form onSubmit={handleSubmit}>
        <Form.Group as={Row} className="mb-3">
          <Form.Label column md={3}>Restaurant name:</Form.Label>
          <Col md={6}>
            <Form.Control name="restaurantName" value={form.restaurantName} onChange={handleChange} isInvalid={!!errors.restaurantName} />
            <Form.Control.Feedback type="invalid">{errors.restaurantName}</Form.Control.Feedback>
          </Col>
        </Form.Group>

        <Form.Group as={Row} className="mb-3">
          <Form.Label column md={3}>Price from:</Form.Label>
          <Col md={3}>
            <Form.Control name="priceFrom" value={form.priceFrom} onChange={handleChange} isInvalid={!!errors.priceFrom} />
            <Form.Control.Feedback type="invalid">{errors.priceFrom}</Form.Control.Feedback>
          </Col>
          <Form.Label column md={2} className="text-end">To:</Form.Label>
          <Col md={3}>
            <Form.Control name="priceTo" value={form.priceTo} onChange={handleChange} isInvalid={!!errors.priceTo} />
            <Form.Control.Feedback type="invalid">{errors.priceTo}</Form.Control.Feedback>
          </Col>
        </Form.Group>

        <Form.Group as={Row} className="mb-3">
          <Form.Label column md={3}>Owner:</Form.Label>
          <Col md={3}>
            <Form.Control name="ownerName" value={form.ownerName} onChange={handleChange} isInvalid={!!errors.ownerName} />
            <Form.Control.Feedback type="invalid">{errors.ownerName}</Form.Control.Feedback>
          </Col>
        </Form.Group>

        <Form.Group as={Row} className="mb-3">
          <Form.Label column md={3} >Address</Form.Label>
          <Col md={6}>
            <Form.Control name="address" placeholder="Address" value={form.address} onChange={handleChange} isInvalid={!!errors.address} />
            <Form.Control.Feedback type="invalid">{errors.address}</Form.Control.Feedback>
          </Col>
        </Form.Group>

        <Form.Group as={Row} className="mb-3">
          <Form.Label column md={3}>Category:</Form.Label>
          <Col md={3}>
            <Form.Select name="categoryId" value={form.categoryId} onChange={handleChange} isInvalid={!!errors.categoryId}>
              <option value="">Select</option>
              {categories.map(c => (
                  <option key={c.categoryId} value={c.categoryId}>{c.categoryName}</option>
              ))}
            </Form.Select>
            <Form.Control.Feedback type="invalid">{errors.categoryId}</Form.Control.Feedback>
          </Col>
          <Form.Label column md={3} className="text-end">Open Date</Form.Label>
          <Col md={3}>
            <Form.Control name="openDate" placeholder="dd/MM/yyyy" value={form.openDate} onChange={handleChange} isInvalid={!!errors.openDate} />
            <Form.Control.Feedback type="invalid">{errors.openDate}</Form.Control.Feedback>
          </Col>
        </Form.Group>

        <Row className="mb-3">
          <Col md={{ span: 6, offset: 3 }} className="d-flex gap-2">
            <Button type="submit" variant="primary">Save</Button>
            <Button variant="secondary" onClick={() => navigate('/')}>Back</Button>
          </Col>
        </Row>
      </Form>

      <hr />
      <footer className="text-center">@2026 FPT University</footer>
    </Container>
  );
}

export default AddRestaurants;
