import { BrowserRouter, Routes, Route } from 'react-router-dom';
import RestaurantsList from './components/RestaurantsList.jsx';
import RestaurantsDetail from './components/RestaurantsDetail.jsx';
import AddRestaurants from './components/AddRestaurants.jsx';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<RestaurantsList />} />
        <Route path="/view/:id" element={<RestaurantsDetail />} />
        <Route path="/add" element={<AddRestaurants />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
