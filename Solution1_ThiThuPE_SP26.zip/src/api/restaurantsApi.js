import axios from 'axios';

const API = axios.create({ baseURL: '/api' });

const buildListParams = ({ name, categoryId, page, size, sortBy }) => {
  const params = { page, size };
  if (name !== undefined && name !== null && name !== '') params.name = name;
  if (categoryId !== undefined && categoryId !== null && categoryId !== '') params.categoryId = categoryId;
  if (sortBy !== undefined && sortBy !== null && sortBy !== '') params.sortBy = sortBy;
  return params;
};

export const getAllRestaurants = (page = 0, size = 5) =>
  API.get('/restaurants', { params: buildListParams({ page, size, sortBy: 'restaurantName' }) });

export const searchRestaurants = (name, categoryId, page = 0, size = 5) =>
  API.get('/restaurants', {
    params: buildListParams({
      name,
      categoryId,
      page,
      size,
      sortBy: 'restaurantName',
    }),
  });

export const getRestaurantsById = (id) => API.get(`/restaurants/${id}`);

export const createRestaurants = (data) => API.post('/restaurants', data);

export const deleteRestaurants = (id) => API.delete(`/restaurants/${id}`);

export const getCategories = () => API.get('/categories');
