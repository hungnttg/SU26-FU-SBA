//product card
import React from "react";
function Price({value}){
    return <h3>{value} VND</h3>
}
function Rating({score}){
    return <p>{score}</p>
}
function Button({text}){
    return <button>{text}</button>
}
//---phan tu
function ProductInfo({name,price,rating}){
    return(
        <div>
            <h2>{name}</h2>
            <Price value={price}/>
            <Rating score={rating}/>
        </div>
    );
}
function ProductCard({product}){
    return(
        <div style={{border:"1px solid gray",padding:20}}>
            <img src="https://placehold.jp/150x150.png" alt=""/>
            <ProductInfo
                name={product.name}
                price={product.price}
                rating={product.rating}
            />
            <Button text="Mua ngay" />
        </div>
    );
}
export default function Slot7_2(){
    const product={
        name: "Laptop Gaming",
        price:"20.000.000",
        rating: 4.9
    };
    return <ProductCard product={product}/>
}