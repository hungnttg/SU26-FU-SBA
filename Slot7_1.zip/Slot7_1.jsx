//login
import React from "react";
function Input({placeholder, type="text"}){
    return <input type={type} placeholder={placeholder}/>
}
function Button({children}){
    return <button>{children}</button>
}
//----phan tu
function Card({children}){
    return(
        <div style={{border:"1px solid gray",padding:20}}>
            {children}
        </div>
    );
}
function FormField({label,children}){
    return(
        <div style={{marginBottom:10}}>
            <label>{label}</label>
            <br/>
            {children}
        </div>
    );
}
//sinh vat
function LoginForm(){
    return(
        <form>
            <FormField label="Email">
                <Input placeholder="Nhap email" />
            </FormField>
            <FormField label="Password">
                <Input type="password" placeholder="Nhap mat khau" />
            </FormField>
            <Button>Dang nhap</Button>
        </form>
    );
}
export default function Slot7_1(){
    return(
        <Card>
            <h2>Login</h2>
            <LoginForm/>
        </Card>
    );
}