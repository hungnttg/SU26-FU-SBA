//fullName
//email
//phone
//company
//experience
//username
//password
import { useState } from "react";
import { useForm } from "react-hook-form";
import {email, z} from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import "../slot23/b.css";

const schema = z.object({
    fullName: z.string().min(3,"Ten qua ngan"),
    email: z.string().email("Email khong hop le"),
    phone: z.string().min(10,"SDT khong hop le"),
    company: z.string().min(2,"Ten cong ty bat buoc"),
    experience: z.string().min(1,"Chon so nam kinh nghiem"),
    username: z.string().min(4,"Username toi thieu 4 ky tu"),
    password: z.string().min(8,"Password toi thieu 8 ky tu")
});
export default function Sloy23_1(){
    const [step,setStep]=useState(1);
    const {
        register,handleSubmit,trigger,getValues,
        formState: {errors}
    } = useForm({
        resolver: zodResolver(schema)
    });
    const nextStep = async () =>{
        let valid = false;
        if(step === 1){
            valid = await trigger([
                "fullName","email","phone"
            ]);
        }
        if(step === 2){
            valid = await trigger([
                "company","experience"
            ]);
        }
        if(step === 3){
            valid = trigger([
                "username","password"
            ]);
        }
        if(valid){
            setStep(step+1);
        }
    };
    const prevStep = () =>{
        setStep(step-1);
    };
    const onSubmit = (data) =>{
        console.log(data);
        alert(
            "Application Submitted\n\n"+ JSON.stringify(data,null,2)
        );
    };
    return(
        <div className="container">
            <h1>Xin viec</h1>
            <h3>
                Step {step}/4
            </h3>
            <form onSubmit={handleSubmit(onSubmit)}>
                {step === 1 && (
                    <>
                        <input
                            placeholder="Full name" {...register("fullName")}
                        />
                        <p className="error">
                            {errors.fullName?.message}
                        </p>
                        <input
                            placeholder="Email" {...register("email")}
                        />
                        <p className="error">
                            {errors.email?.message}
                        </p>
                        <input
                            placeholder="Phone" {...register("phone")}
                        />
                        <p className="error">
                            {errors.phone?.message}
                        </p>
                        <button type="button" onClick={nextStep}>Next</button>
                    </>
                )}
                {step === 2 && (
                    <>
                        <input
                            placeholder="Current Company" {...register("company")}
                        />
                        <p className="error">
                            {errors.company?.message}
                        </p>
                        <select {...register("experience")}>
                            <option value="">
                                Chon kinh nghiem
                            </option>
                            <option value="1">1 nam</option>
                            <option value="2">2 nam</option>
                            <option value="3">3+ nam</option>
                        </select>
                        <p className="error">
                            {errors.experience?.message}
                        </p>
                        <button type="button" onClick={prevStep}>Back</button>
                        <button type="button" onClick={nextStep}>Next</button>
                    </>
                )}
                {step === 3 && (
                    <>
                        <input
                            placeholder="Username" {...register("username")}
                        />
                        <p className="error">
                            {errors.username?.message}
                        </p>
                        <input type="password"
                            placeholder="Password" {...register("password")}
                        />
                        <p className="error">
                            {errors.password?.message}
                        </p>
                        <button type="button" onClick={prevStep}>Back</button>
                        <button type="button" onClick={nextStep}>Review</button>
                    </>
                )}
                {step === 4 && (
                    <>
                        <h3>Review Information</h3>
                        <pre>
                            {JSON.stringify(
                                getValues(),
                                null,
                                2
                            )}
                        </pre>
                        <button type="button" onClick={prevStep}>Back</button>
                        <button type="submit">Submit</button>
                    </>
                )}
            </form>
        </div>
    );
}