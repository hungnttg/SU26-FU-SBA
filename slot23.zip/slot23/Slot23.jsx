//Signup form
//npm i react-hook-form zod @hookform/resolvers
import { useForm } from "react-hook-form";
import {z} from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import "../slot23/a.css";
const signupSchema = z
.object({
    fullName: z
    .string()
    .min(3,"Ten toi thieu phai co it nhat 3 ky tu"),

    email: z
    .string()
    .email("Email khong hop le"),

    password: z
    .string()
    .min(8,"Mat khau toi thieu phai co 8 ky tu"),

    confirmPassword: z.string()
})
.refine(
    (data)=>data.password === data.confirmPassword,
    {
        path: ["confirmPassword"],
        message:"Mat khau xac nhan khong khop"
    }
);
export default function Slot23(){
    const {
        register, handleSubmit, reset,
        formState: {errors}
    } = useForm({
        resolver: zodResolver(signupSchema)
    });
    const onSubmit = (data) =>{
        alert(
            "Dang ky thanh cong!\n\n"+ JSON.stringify(data,null,2)
        );
        reset();
    };
    //layout
    return(
        <div className="container">
            <h1>Signup Form</h1>
            <form onSubmit={handleSubmit(onSubmit)}>
                <input
                    placeholder="Ho va ten"
                    {...register("fullName")}
                />
                <p className="error">
                    {errors.fullName?.message}
                </p>
                <input
                    placeholder="Email"
                    {...register("email")}
                />
                <p className="error">
                    {errors.email?.message}
                </p>
                <input
                    placeholder="Password"
                    type="password"
                    {...register("password")}
                />
                <p className="error">
                    {errors.password?.message}
                </p>
                <input
                    type="password"
                    placeholder="confirm Password"
                    {...register("confirmPassword")}
                />
                <p className="error">
                    {errors.confirmPassword?.message}
                </p>
                <button>
                    Register
                </button>
            </form>
        </div>
    );
    
}