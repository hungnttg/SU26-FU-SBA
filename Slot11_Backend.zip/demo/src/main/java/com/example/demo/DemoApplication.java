package com.example.demo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonSerializeAs;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.*;

import java.lang.annotation.Annotation;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@SpringBootApplication
@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    private final UserRepository userRepository;
    public DemoApplication(UserRepository userRepository){
        this.userRepository=userRepository;
    }
        //GET
        @GetMapping("/user")
        public List<User> getUser(){
            return userRepository.findAll();
        }
        @PostMapping("/user")
        public String createUser(@RequestBody User user){
            userRepository.save(user);
            return "Receiver: "+user.getName()+", Birthday: "+user.birthday;
        }
    //==================custom Serializer


}

