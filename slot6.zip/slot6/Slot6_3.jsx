//ban hang
//Navbar
//List Product
//Modal
//Login
import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import { Button, Card, Col, Container, Form, Modal, Nav, Navbar, Row } from 'react-bootstrap';
export default function Slot6_3(){
    //--------------code-------------------
    //quan ly trang thai
    const [showModal,setShowModal]=useState(false);//ban dau khong hien thi modal
    const [selectedProduct,setSelectedProduct]=useState(null);//ban dau khong chon sp
    const [showLogin,setShowLogin]=useState(false);
    //san pham hien thi: API
    const products = [
        {id:1,name:"San pham 1", price:"150.000d",description:"Mo ta san pham 1"},
        {id:2,name:"San pham 2", price:"550.000d",description:"Mo ta san pham 2"},
        {id:3,name:"San pham 3", price:"450.000d",description:"Mo ta san pham 3"},
        {id:4,name:"San pham 4", price:"330.000d",description:"Mo ta san pham 4"},
        {id:5,name:"San pham 5", price:"120.000d",description:"Mo ta san pham 5"},
    ];
    //cac ham xu ly
    //ham hien thi chi tiet san pham
    const handleShowDetail = (product) =>{
        setSelectedProduct(product);
        setShowModal(true);
    };
    //ham submit login
    const handleLoginSubmit = (event) =>{
        event.preventDefault();//cam submit tu dong
        alert("Login successfull");
        setShowLogin(false);
    };
    //--------------layout--------------------
    return(
        <>
            <Navbar bg='light' variant='light' expand='lg' fixed='top'>
                <Container>
                    <Navbar.Brand href='#'>Shop ban hang</Navbar.Brand>
                    <Navbar.Toggle aria-controls='basic-navbar-nav'/>
                    <Navbar.Collapse id='basic-navbar-nav'>
                        <Nav className='me-auto'>
                            <Nav.Link href='#'>Trang chu</Nav.Link>
                            <Nav.Link href='#'>San pham</Nav.Link>
                            <Nav.Link href='#'>Gio hang</Nav.Link>
                        </Nav>
                        <Button variant='outline-primary' onClick={()=>setShowLogin(true)}>
                            Dang nhap
                        </Button>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
            {/* them khoang cach */}
            <div style={{marginTop:"80px"}}>
                <Container className='mt-4'>
                    <Row>
                        {products.map((p)=>(
                            <Col key={p.id} md={4} className='mb-4'>
                                <Card>
                                    <Card.Body>
                                        <Card.Title>{p.name}</Card.Title>
                                        <Card.Text>Gia: {p.price}</Card.Text>
                                        <Button variant='primary' onClick={()=> handleShowDetail(p)}>
                                            Xem chi tiet
                                        </Button>
                                    </Card.Body>
                                </Card>
                            </Col>
                        ))}
                    </Row>
                </Container>
            </div>
            {/* modal xu ly hien thi chi tiet san pham */}
            <Modal show={showModal} onHide={()=>setShowModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>{selectedProduct?.name}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p><b>Gia:</b>{selectedProduct?.price}</p>
                    <p><b>MO ta:</b>{selectedProduct?.description}</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant='secondary' onClick={()=>setShowModal(false)}>Close</Button>
                    <Button variant='success'>Add to cart</Button>
                </Modal.Footer>
            </Modal>
            {/* modal dang nhap */}
            <Modal show={showLogin} onHide={()=>setShowLogin(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Dang nhap</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleLoginSubmit}>
                        <Form.Group className='mb-3' controlId='formBasicEmail'>
                            <Form.Label>Email</Form.Label>
                            <Form.Control type='email' placeholder='Nhap email' required/>
                        </Form.Group>
                        <Form.Group className='mb-3' controlId='formBasicPassword'>
                            <Form.Label>Password</Form.Label>
                            <Form.Control type='password' placeholder='Nhap password' required/>
                        </Form.Group>
                        <Button variant='primary' type='submit' className='w-100'>Dang nhap</Button>
                    </Form>
                </Modal.Body>
            </Modal>
        </>
    );
}