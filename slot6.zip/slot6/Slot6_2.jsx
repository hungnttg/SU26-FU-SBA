import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import { Button, Modal } from 'react-bootstrap';
export default function Slot6_2(){
    // modal: display a detail product
    const [show,setShow]=useState(false);//ban dau chua hien thi modal
    //dinh nghia ham quan ly open/close modal
    const handleClose = () => setShow(false); //dong modal
    const handleShow = () => setShow(true);//mo modal
    return(
        <div style={{padding:"20px"}}>
            <Button variant='info' onClick={handleShow}>Product Detail</Button>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Thong tin san pham</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    Day la phan mo ta chi tiet san pham
                </Modal.Body>
                <Modal.Footer>
                    <Button variant='secondary' onClick={handleClose}>Close</Button>
                    <Button variant='primary' onClick={handleClose}>Mua ngay</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}