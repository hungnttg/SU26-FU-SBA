import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Form } from 'react-bootstrap';
export default function Slot6_1(){
    // login form
    return(
        <div style={{width:"300px",margin:"50px auto"}}>
            <h2>Login</h2>
            <Form>
                <Form.Group className='mb-3'>
                    <Form.Label>Email</Form.Label>
                    <Form.Control type='email' placeholder='Enter email'/>
                </Form.Group>
                <Form.Group className='mb-3'>
                    <Form.Label>Password</Form.Label>
                    <Form.Control type='password' placeholder='ENter pass'/>
                </Form.Group>
                <Button variant='primary' type='submit'>Login</Button>
            </Form>
        </div>
    );
}