package com.example.demo;

import jakarta.persistence.*;

@Entity
@Table(name = "sanpham")
public class SanPham {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "giasanpham")
    private Integer giasanpham;
    @Column(name="hinhanhsanpham")
    private String hinhanhsanpham;
    @Column(name="idsanpham")
    private Integer idsanpham;
    @Column(name="motasanpham",columnDefinition = "TEXT")
    private String motasanpham;
    @Column(name = "tensanpham")
    private String tensanpham;

    public SanPham() {
    }

    public SanPham(Integer id, Integer giasanpham, String hinhanhsanpham, Integer idsanpham, String motasanpham, String tensanpham) {
        this.id = id;
        this.giasanpham = giasanpham;
        this.hinhanhsanpham = hinhanhsanpham;
        this.idsanpham = idsanpham;
        this.motasanpham = motasanpham;
        this.tensanpham = tensanpham;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getGiasanpham() {
        return giasanpham;
    }

    public void setGiasanpham(Integer giasanpham) {
        this.giasanpham = giasanpham;
    }

    public String getHinhanhsanpham() {
        return hinhanhsanpham;
    }

    public void setHinhanhsanpham(String hinhanhsanpham) {
        this.hinhanhsanpham = hinhanhsanpham;
    }

    public Integer getIdsanpham() {
        return idsanpham;
    }

    public void setIdsanpham(Integer idsanpham) {
        this.idsanpham = idsanpham;
    }

    public String getMotasanpham() {
        return motasanpham;
    }

    public void setMotasanpham(String motasanpham) {
        this.motasanpham = motasanpham;
    }

    public String getTensanpham() {
        return tensanpham;
    }

    public void setTensanpham(String tensanpham) {
        this.tensanpham = tensanpham;
    }
}
