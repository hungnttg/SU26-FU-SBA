// navbar: navigation; you can add logo, link, button, icon to navbar
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Nav, Navbar } from 'react-bootstrap';
export default function Slot5_4(){
    return(
        <Navbar bg='dark' variant='dark' expand="lg">
            <Container>
                <Navbar.Brand href='#home'>Home</Navbar.Brand>
                <Nav className='me-auto'>
                    <Nav.Link href='#products'>Products</Nav.Link>
                    <Nav.Link href='#about'>About</Nav.Link>
                </Nav>
            </Container>
        </Navbar>
    );
}