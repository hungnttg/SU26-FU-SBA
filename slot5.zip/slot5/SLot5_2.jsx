import 'bootstrap/dist/css/bootstrap.min.css';
import  Card  from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
export default function Slot5_2(){
    // using card
    return(
        <div style={{padding:"20px"}}>
            <Card style={{width: '18rem'}}>
                {/* picture */}
                <Card.Img variant='top' src='https://placehold.co/400'/>
                <Card.Body>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                        Noi dung chinh trong card
                    </Card.Text>
                    <Button variant='primary'>More info</Button>
                </Card.Body>
            </Card>
        </div>
    );

}