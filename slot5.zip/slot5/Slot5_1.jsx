import  Button  from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
export default function Slot5_1(){
    // using button
    return(
        <div style={{padding:"20px"}}>
            <h1>Button in React-Bootstrap</h1>
            <Button variant="primary">Primary</Button>{' '}
            <Button variant="success">Success</Button>{' '}
            <Button variant='danger'>Danger</Button>{' '}
            <Button variant='outline-dark'>Outline</Button>
        </div>
    );
}