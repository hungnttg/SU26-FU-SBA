import 'bootstrap/dist/css/bootstrap.min.css';
import { Card, Col, Container, Row } from 'react-bootstrap';
export default function Slot5_3(){
    return(
        <Container>
            <h1 className='mt-3'>Grid System</h1>
            <Row>
                <Col md={4}>
                    <Card>
                        <Card.Body>Col 1</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Col 2</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Col 3</Card.Body>
                    </Card>
                </Col>
                <Col md={4}>
                    <Card>
                        <Card.Body>Col 4</Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}